package com.example.zykova_pr_31_v2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class SigninScreen : AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_screen)
    }

    fun Signin(view: View) {}
}